<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">


<html>
<head>
    <title> Conditional Statements</title>

<style>
.box {
	border-radius:5px;
	 -webkit-border-radius:5px;
	padding:20px;
}
a{
color:#ffffff;
text-decoration:none;
}
b {
background:#008090;
padding:20px;
border-radius:10px;
}
</style>

</head>
<body>
<form action="process.php" method="post">
<input type="text" name="temp" class="box" maxlength="2"/>
<input type="submit" value="submit"/>
</form>
<br/>

<a href="switch.php"><b>Switch()</b></a>
</body>
</html>