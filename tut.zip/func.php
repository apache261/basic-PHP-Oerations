<?php

function sumNumber ($strt, $end){
 $sum = $strt + $end;
return $sum;
}

function subNumber ($strt,$end){
$difference = $strt - $end;
return $difference;

}

function productNumber ($strt, $end){
$product = $strt * $end;
return $product;

}

?>