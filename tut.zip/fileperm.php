<?php
if (count(get_included_files()) == 1) {
	echo '<div class="ans"><p> 403, Forbidden </p></div>';
	}
?>